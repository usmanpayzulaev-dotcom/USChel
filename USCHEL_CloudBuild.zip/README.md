# USCHEL — cloud APK build

Этот проект настроен для сборки APK через GitHub Actions, без Android Studio.

1. Создайте GitHub-репозиторий и загрузите сюда все файлы.
2. Откройте вкладку Actions.
3. Выберите **Build USCHEL APK** → **Run workflow**.
4. После завершения откройте запуск workflow и скачайте artifact **USCHEL**.
5. Внутри будет `app-debug.apk`.

Это debug-APK для установки на Android. Для публикации в Google Play позже понадобится release-подпись.
